package com.example.aikeyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.content.ClipDescription
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File
import android.widget.*

class KeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var rows: LinearLayout
    private lateinit var status: TextView
    private var mode = "ar"          // ar | en | num | emo
    private var shift = false
    private var dark = true
    private var result: String? = null
    private var replaceAll = true

    private val arRows = listOf("ضصثقفغعهخحج", "شسيبلاتنمكط", "⇧ئءؤرىةوز⌫")
    private val arShiftRows = listOf("َُِّْ", "ًٌٍ", "⇧ٰ،؛؟⌫")
    private val enRows = listOf("qwertyuiop", "asdfghjkl", "⇧zxcvbnm⌫")
    private val numRows = listOf("1234567890", "@#\$%&-+()/", "*\"':;!؟،~⌫")
    private val emoRows = listOf("😀😂🥰😎🤩🥳😭😡🤯🫡", "🔥✨🎉👏🙏💯☕🌹🚀💡", "👍👎🤝💪👀✅❌📍⌫")

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        dark = getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("dark", true)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8) }
        val bar = LinearLayout(this)
        listOf("✨ تصحيح" to "spell", "👔 رسمي" to "formal", "😊 ودي" to "friendly",
            "🌐 ترجمة" to "translate", "💡 رد" to "reply").forEach { (t, m) -> bar.addView(chip(t) { ai(m) }) }
        bar.addView(chip("🖼 ملصقات") { mode = if (mode == "stk") "ar" else "stk"; shift = false; render() })
        bar.addView(chip("📋") { clip()?.let { type(it) } })
        bar.addView(chip("🎨") {
            dark = !dark
            getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putBoolean("dark", dark).apply(); paint(); render()
        })
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(bar) })
        status = TextView(this).apply {
            textSize = 13f; maxLines = 3; setPadding(12, 10, 12, 10); text = "اكتب نصاً ثم اختر أداة. «رد»: انسخ الرسالة الواردة أولاً."
            setOnClickListener { applyResult() }
        }
        root.addView(status)
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(rows)
        paint(); render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (::rows.isInitialized) { shift = false; render() }
    }

    private fun fg() = if (dark) Color.parseColor("#22D3EE") else Color.parseColor("#0F172A")
    private fun keyBg() = if (dark) Color.parseColor("#1E293B") else Color.WHITE
    private fun paint() {
        root.setBackgroundColor(if (dark) Color.parseColor("#090D16") else Color.parseColor("#E2E8F0"))
        status.setTextColor(if (dark) Color.WHITE else Color.BLACK)
    }

    private fun shape(c: Int) = GradientDrawable().apply { cornerRadius = 18f; setColor(c) }
    private fun chip(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(Color.WHITE); setPadding(26, 14, 26, 14)
        background = shape(Color.parseColor("#6366F1"))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(4, 0, 4, 0) }
        setOnClickListener { f() }
    }

    private fun render() {
        rows.removeAllViews()
        if (mode == "stk") { rows.addView(stickerStrip()); rows.addView(row(listOf("أبج"), true)); return }
        val layout = when (mode) {
            "ar" -> if (shift) arShiftRows else arRows
            "en" -> enRows; "num" -> numRows; else -> emoRows
        }
        val rtl = mode == "ar" || mode == "num" || mode == "emo"
        layout.forEach { rows.addView(row(keysOf(it), rtl)) }
        val bottom = listOf(if (mode == "num" || mode == "emo") "أبج" else "123", "😊", "🌐", "␣", ".", "⏎")
        rows.addView(row(bottom, rtl))
    }

    private fun keysOf(s: String) = s.codePoints().toArray().map { String(Character.toChars(it)) }

    private fun row(keys: List<String>, rtl: Boolean) = LinearLayout(this).apply {
        layoutDirection = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        keys.forEach { k ->
            val wide = k == "␣"
            val label = when {
                k == "⇧" && mode == "ar" -> "تشكيل"
                k == "⇧" && mode == "en" && shift -> "⬆"
                k.length == 1 && Character.getType(k[0]) == Character.NON_SPACING_MARK.toInt() -> "ـ$k"
                k == "␣" -> if (mode == "en") "Space" else "مسافة"
                else -> k
            }
            addView(TextView(context).apply {
                text = label; textSize = 20f; gravity = Gravity.CENTER; setTextColor(fg())
                background = shape(keyBg()); minHeight = 120
                layoutParams = LinearLayout.LayoutParams(0, -2, if (wide) 4f else 1f).apply { setMargins(3, 3, 3, 3) }
                setOnClickListener { press(k) }
            })
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun stickerStrip(): View {
        val strip = LinearLayout(this)
        fun lp() = LinearLayout.LayoutParams(dp(88), dp(88)).apply { setMargins(6, 6, 6, 6) }
        strip.addView(TextView(this).apply {
            text = "＋\nجديد"; gravity = Gravity.CENTER; setTextColor(fg()); background = shape(keyBg()); layoutParams = lp()
            setOnClickListener {
                startActivity(Intent(this@KeyboardService, StickerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        StickerStore.list(this).forEach { f ->
            val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 4 })
            strip.addView(ImageView(this).apply {
                setImageBitmap(bmp); layoutParams = lp()
                setOnClickListener { sendSticker(f) }
                setOnLongClickListener { f.delete(); render(); true }
            })
        }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) }
    }

    private fun sendSticker(f: File) {
        val info = currentInputEditorInfo ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        val supported = EditorInfoCompat.getContentMimeTypes(info).any { ClipDescription.compareMimeTypes("image/png", it) }
        var sent = false
        if (supported && currentInputConnection != null) {
            grantUriPermission(info.packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val content = InputContentInfoCompat(uri, ClipDescription("sticker", arrayOf("image/png")), null)
            sent = InputConnectionCompat.commitContent(
                currentInputConnection, info, content, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)
        }
        if (!sent) {   // التطبيق لا يقبل الصور من الكيبورد: نفتح قائمة المشاركة
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(share, "إرسال الملصق").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private fun type(s: String) { currentInputConnection?.commitText(s, 1) }

    private fun press(k: String) {
        val ic = currentInputConnection ?: return
        when (k) {
            "⌫" -> if (ic.getSelectedText(0).isNullOrEmpty()) ic.deleteSurroundingTextInCodePoints(1, 0) else ic.commitText("", 1)
            "⇧" -> { shift = !shift; render() }
            "123" -> { mode = "num"; render() }
            "أبج" -> { mode = "ar"; shift = false; render() }
            "😊" -> { mode = "emo"; render() }
            "🌐" -> { mode = if (mode == "ar") "en" else "ar"; shift = false; render() }
            "␣" -> ic.commitText(" ", 1)
            "⏎" -> {
                val a = (currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
                if (a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(a)
                else ic.commitText("\n", 1)
            }
            else -> { ic.commitText(if (mode == "en" && shift) k.uppercase() else k, 1); if (mode == "en" && shift) { shift = false; render() } }
        }
    }

    private fun clip(): String? =
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()

    private fun ai(m: String) {
        val ic = currentInputConnection ?: return
        val text = if (m == "reply") clip().orEmpty()
        else (ic.getTextBeforeCursor(5000, 0) ?: "").toString() + (ic.getTextAfterCursor(5000, 0) ?: "").toString()
        if (text.isBlank()) { status.text = "⚠️ لا يوجد نص لمعالجته"; return }
        replaceAll = m != "reply"; result = null; status.text = "⏳ جاري المعالجة..."
        AiClient.run(this, m, text) { r ->
            ui.post {
                result = r.getOrNull()
                status.text = if (result != null) "$result\n\n(اضغط هنا للاعتماد ✓)" else "⚠️ تعذر الاتصال بالخادم، راجع الإعدادات"
            }
        }
    }

    private fun applyResult() {
        val ic = currentInputConnection ?: return
        val res = result ?: return
        if (replaceAll) {
            val b = ic.getTextBeforeCursor(10000, 0)?.length ?: 0
            val a = ic.getTextAfterCursor(10000, 0)?.length ?: 0
            ic.deleteSurroundingText(b, a)
        }
        ic.commitText(res, 1); result = null; status.text = "تم ✓"
    }
}
